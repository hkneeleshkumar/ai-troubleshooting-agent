# AI Troubleshooting Agent

An open-source starter application for investigating application incidents from logs. It combines a Spring Boot API, a Python analysis service, a lightweight React UI, and an optional local LLM/RAG path.

## What it does
- Paste or upload log text and analyze it.
- Detect common Java/Spring/database/network errors using deterministic rules.
- Return severity, evidence excerpts, likely causes, and safe next checks.
- Optionally retrieve matching runbook snippets from a local knowledge base.
- Optionally ask a locally hosted Ollama model for an evidence-grounded explanation.
- Keep the model advisory: no shell commands or remediation actions are executed.

## Stack
- Backend API: Java 21, Spring Boot 3, Maven
- Analysis service: Python 3.11+, FastAPI
- UI: React + Vite
- Retrieval: TF-IDF similarity (scikit-learn)
- Optional LLM: Ollama-compatible HTTP API
- Local run: Docker Compose

## Run with Docker
```bash
docker compose up --build
```
Open the UI at http://localhost:5173. API: http://localhost:8080. Python service: http://localhost:8000.

## Run locally
1. Start analysis service:
   ```bash
   cd ai-service
   python -m venv .venv
   # Windows: .venv\\Scripts\\activate
   # macOS/Linux: source .venv/bin/activate
   pip install -r requirements.txt
   uvicorn app.main:app --reload --port 8000
   ```
2. Start backend:
   ```bash
   cd backend
   mvn spring-boot:run
   ```
3. Start frontend:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

## Optional Ollama
Set `OLLAMA_BASE_URL` (default `http://host.docker.internal:11434`) and `OLLAMA_MODEL` (default `llama3.2`) in the Python service environment. Pull the model in Ollama first. The app falls back to deterministic analysis if Ollama is unavailable.

## API
- `POST /api/analyze` — body: plain text logs
- `GET /api/health` — backend health
- `GET http://localhost:8000/health` — AI service health
- `POST http://localhost:8000/analyze` — analysis request JSON

## Safety and privacy
Do not submit production logs containing credentials, tokens, personal data, or customer information. This demo does not automatically redact all sensitive data. Review and sanitize logs before use. AI findings are suggestions, not confirmed root causes.

## Testing
```bash
cd backend && mvn test
cd ../ai-service && pytest
```

## Contributing
Please open an issue before large changes. Add tests for new detectors and keep sample logs synthetic.

## License
MIT
