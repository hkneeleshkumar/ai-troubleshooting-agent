package dev.neelesh.troubleshooting;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.Map;
@Service
public class AnalysisService {
 private final RestClient client;
 public AnalysisService(@Value("${ai.service.url}") String url) {
  this.client = RestClient.builder().baseUrl(url).build();
 }
 public AnalysisDto analyze(String logs) {
  return client.post().uri("/analyze").body(Map.of("logs", logs)).retrieve().body(AnalysisDto.class);
 }
}
