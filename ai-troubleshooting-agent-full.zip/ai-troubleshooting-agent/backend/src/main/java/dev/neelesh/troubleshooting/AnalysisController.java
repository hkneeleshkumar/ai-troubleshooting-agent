package dev.neelesh.troubleshooting;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api")
public class AnalysisController {
 private final AnalysisService service;
 public AnalysisController(AnalysisService service) { this.service = service; }
 @PostMapping(value="/analyze", consumes=MediaType.TEXT_PLAIN_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
 public AnalysisDto analyze(@RequestBody String logs) {
  if (logs == null || logs.isBlank()) throw new IllegalArgumentException("Log content must not be empty.");
  if (logs.length() > 500_000) throw new IllegalArgumentException("Log content exceeds 500 KB.");
  return service.analyze(logs);
 }
 @GetMapping("/health") public Map<String,String> health() { return Map.of("status","UP"); }
}
