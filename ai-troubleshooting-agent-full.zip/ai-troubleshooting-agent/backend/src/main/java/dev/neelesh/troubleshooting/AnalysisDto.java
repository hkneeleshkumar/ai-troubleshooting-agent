package dev.neelesh.troubleshooting;
import java.util.List;
public record AnalysisDto(int issueCount, String summary, List<Issue> issues, String source) {
 public record Issue(String category, String severity, String evidence, String likelyCause,
                     List<String> recommendedChecks, double confidence) {}
}
