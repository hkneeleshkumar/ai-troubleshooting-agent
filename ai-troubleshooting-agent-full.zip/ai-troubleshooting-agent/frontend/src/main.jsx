import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

function App() {
  const [logs, setLogs] = useState('');
  const [useLlm, setUseLlm] = useState(false);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function analyze(e) {
    e.preventDefault();
    setBusy(true); setError(''); setResult(null);
    try {
      const response = await fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:8080'}/api/analyze`, {
        method: 'POST', headers: {'Content-Type':'text/plain'}, body: logs
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Analysis failed');
      setResult(data);
    } catch (err) { setError(err.message || 'Could not reach the API.'); }
    finally { setBusy(false); }
  }

  return <main className="shell">
    <header><div className="mark">◎</div><div><p className="eyebrow">INCIDENT INTELLIGENCE</p><h1>AI Troubleshooting Agent</h1><p className="sub">Turn noisy application logs into evidence-led next steps.</p></div></header>
    <section className="panel">
      <form onSubmit={analyze}>
        <label htmlFor="logs">Application logs</label>
        <textarea id="logs" value={logs} onChange={e=>setLogs(e.target.value)} placeholder={'Paste sanitized logs here…\nExample: java.lang.NullPointerException at Demo.java:12'} required />
        <div className="controls"><label className="toggle"><input type="checkbox" checked={useLlm} onChange={e=>setUseLlm(e.target.checked)}/> Ask optional Ollama model for a summary</label><button disabled={busy || !logs.trim()}>{busy ? 'Analyzing…' : 'Analyze logs'}</button></div>
        <p className="privacy">Use synthetic or sanitized logs. Never paste credentials or customer data.</p>
      </form>
    </section>
    {error && <p className="error">{error}</p>}
    {result && <section className="results">
      <div className="result-head"><div><p className="eyebrow">ANALYSIS RESULT</p><h2>{result.issueCount} issue pattern(s) detected</h2></div><span className="source">{result.source}</span></div>
      <p className="summary">{result.summary}</p>
      {result.issues?.map((issue,i)=><article className="issue" key={i}>
        <div className="issue-title"><h3>{issue.category}</h3><span className={`severity ${issue.severity?.toLowerCase()}`}>{issue.severity}</span></div>
        <p><b>Likely explanation:</b> {issue.likelyCause}</p><pre>{issue.evidence}</pre>
        <h4>Recommended checks</h4><ul>{issue.recommendedChecks?.map((x,j)=><li key={j}>{x}</li>)}</ul>
      </article>)}
      {result.runbookMatches?.length > 0 && <div className="runbooks"><h3>Related runbooks</h3>{result.runbookMatches.map((r,i)=><details key={i}><summary>{r.title} · relevance {r.score}</summary><p>{r.text}</p></details>)}</div>}
      <p className="disclaimer">Findings are advisory and are not a confirmed root cause.</p>
    </section>}
    <footer>Built for safe, evidence-based incident investigation · Open source starter</footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<App />);
