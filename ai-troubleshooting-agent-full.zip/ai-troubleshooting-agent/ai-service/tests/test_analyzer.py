from app.analyzer import rule_analyze, retrieve

def test_detects_null_pointer():
    issues = rule_analyze("java.lang.NullPointerException at Demo.java:8")
    assert len(issues) == 1
    assert issues[0]["category"] == "Null pointer"

def test_detects_multiple_patterns():
    issues = rule_analyze("Read timed out; java.lang.OutOfMemoryError: Java heap space")
    assert {x["category"] for x in issues} == {"Timeout", "Out of memory"}

def test_retrieval_returns_context():
    matches = retrieve("database connection refused")
    assert matches
    assert matches[0]["title"] == "Database connection failure"
