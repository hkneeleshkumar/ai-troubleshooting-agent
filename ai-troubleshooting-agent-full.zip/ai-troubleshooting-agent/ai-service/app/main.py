from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .analyzer import analyze_logs
app = FastAPI(title="AI Troubleshooting Agent", version="1.0.0")
class AnalyzeRequest(BaseModel):
    logs: str = Field(min_length=1, max_length=500_000)
    use_llm: bool = False
@app.get("/health")
def health():
    return {"status": "UP"}
@app.post("/analyze")
async def analyze(request: AnalyzeRequest):
    if not request.logs.strip():
        raise HTTPException(status_code=400, detail="Log content must not be blank.")
    return await analyze_logs(request.logs, request.use_llm)
