import os
import re
from typing import Any
import httpx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .knowledge import RUNBOOKS

RULES = [
    ("Null pointer", "ERROR", re.compile(r"NullPointerException", re.I),
     "A null reference was likely dereferenced.", ["Inspect the stack trace line.", "Check nullability and object initialization.", "Add a regression test."]),
    ("Database connectivity", "ERROR", re.compile(r"Connection refused|could not connect|SQLTransientConnectionException|Communications link failure", re.I),
     "The database may be unreachable or the connection pool may be exhausted.", ["Verify database host, port, and network access.", "Check database health and connection-pool metrics.", "Review credentials and recent config changes."]),
    ("Timeout", "WARN", re.compile(r"timed out|TimeoutException|Read timed out|deadline exceeded", re.I),
     "A dependency or operation may be slower than its configured timeout.", ["Check downstream latency and traces.", "Review timeout values.", "Use bounded retries with backoff."]),
    ("Out of memory", "CRITICAL", re.compile(r"OutOfMemoryError|Java heap space", re.I),
     "The JVM may have exhausted available heap.", ["Review heap and GC metrics.", "Inspect a heap dump in a safe environment.", "Look for unbounded caches or retained objects."]),
    ("HTTP 5xx", "ERROR", re.compile(r"\bHTTP/1\.[01]"?\s+5\d\d|\bstatus(?:Code)?[=: ]+5\d\d", re.I),
     "A server-side request failure was logged.", ["Correlate request IDs.", "Check service health and deployment history.", "Inspect dependency failures."]),
    ("Kafka consumer lag", "WARN", re.compile(r"consumer lag|records-lag|lagging consumer", re.I),
     "Consumer processing may not be keeping pace with incoming events.", ["Inspect lag per partition.", "Check processing duration and consumer errors.", "Review partition and consumer capacity."])
]

def retrieve(log_text: str, top_k: int = 2) -> list[dict[str, Any]]:
    corpus = [item["text"] for item in RUNBOOKS]
    vectorizer = TfidfVectorizer(stop_words="english")
    matrix = vectorizer.fit_transform(corpus + [log_text])
    scores = cosine_similarity(matrix[-1], matrix[:-1]).ravel()
    ranked = scores.argsort()[::-1][:top_k]
    return [{"title": RUNBOOKS[i]["title"], "text": RUNBOOKS[i]["text"], "score": round(float(scores[i]), 3)}
            for i in ranked if scores[i] > 0]

def rule_analyze(log_text: str) -> list[dict[str, Any]]:
    issues = []
    for category, severity, pattern, cause, checks in RULES:
        match = pattern.search(log_text)
        if match:
            start, end = max(0, match.start()-100), min(len(log_text), match.end()+160)
            evidence = re.sub(r"\s+", " ", log_text[start:end]).strip()
            issues.append({"category": category, "severity": severity, "evidence": evidence,
                           "likelyCause": cause, "recommendedChecks": checks, "confidence": 0.72})
    return issues

async def llm_summary(log_text: str, issues: list[dict[str, Any]], runbooks: list[dict[str, Any]]) -> str | None:
    base = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434").rstrip("/")
    model = os.getenv("OLLAMA_MODEL", "llama3.2")
    prompt = (
        "You are a cautious incident investigation assistant. Use only the log evidence and supplied runbook context. "
        "Do not claim a root cause is confirmed. Do not provide commands that modify systems. "
        "Respond in 3 concise sentences: observed evidence, likely explanation, next safe checks. "
        f"\nLOG EVIDENCE:\n{log_text[:5000]}\nDETECTED ISSUES:\n{issues}\nRUNBOOK CONTEXT:\n{runbooks}"
    )
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.post(f"{base}/api/generate", json={"model": model, "prompt": prompt, "stream": False})
            response.raise_for_status()
            return response.json().get("response")
    except Exception:
        return None

async def analyze_logs(log_text: str, use_llm: bool = False) -> dict[str, Any]:
    issues = rule_analyze(log_text)
    refs = retrieve(log_text)
    summary = f"Detected {len(issues)} issue pattern(s)." if issues else "No supported issue pattern was detected. Review the raw logs and telemetry."
    source = "rules+retrieval"
    if use_llm:
        generated = await llm_summary(log_text, issues, refs)
        if generated:
            summary = generated.strip()
            source = "rules+retrieval+ollama"
    return {"issueCount": len(issues), "summary": summary, "issues": issues, "runbookMatches": refs, "source": source}
