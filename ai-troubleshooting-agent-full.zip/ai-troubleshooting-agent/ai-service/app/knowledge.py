RUNBOOKS = [
 {"title":"NullPointerException", "text":"A NullPointerException commonly occurs when code dereferences a null reference. Inspect the exact stack trace line, validate inputs, review object initialization, and add a regression test."},
 {"title":"Database connection failure", "text":"Connection refused or SQL connection exceptions may indicate the database is unavailable, host or port is incorrect, network rules block access, credentials are invalid, or the connection pool is exhausted. Check service health and pool metrics."},
 {"title":"Request timeout", "text":"Timeouts can arise from slow dependencies, overloaded services, network latency, or overly strict timeout settings. Check distributed traces and latency metrics; ensure retries use backoff and do not amplify load."},
 {"title":"OutOfMemoryError", "text":"Java heap exhaustion may result from memory leaks, unbounded caches or collections, oversized workloads, or undersized heap. Review GC logs and heap metrics; inspect a heap dump in a safe environment."},
 {"title":"HTTP 5xx", "text":"Server-side 5xx errors can be caused by application exceptions, downstream failures, saturation, or bad deployments. Correlate request IDs, check service health, deployment history, and dependency latency."},
 {"title":"Kafka consumer lag", "text":"Consumer lag may result from insufficient consumer capacity, slow processing, partition imbalance, or downstream bottlenecks. Inspect lag by partition, processing time, errors, and consumer group rebalances."}
]
